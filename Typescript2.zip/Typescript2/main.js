// function log(message){
//   console.log(message);
// }
// var message = 'Hello World';
// log(message);
function doSomething() {
    for (var i = 0; i < 5; i++) {
        console.log(i);
    }
    console.log('Finally: ' + i);
}
doSomething();
// let count = 5;
// count ='a';
var a;
a = 1;
//warning type
// a= true;
// a ='a';
var b;
var c;
var d;
var e = [1, 2, 3];
var f = [1, true, 'a', false];
var ColorRed = 0;
var ColorGreen = 1;
var ColorBlue = 2;
var Color;
(function (Color) {
    Color[Color["Red"] = 0] = "Red";
    Color[Color["Green"] = 1] = "Green";
    Color[Color["Blue"] = 2] = "Blue";
})(Color || (Color = {}));
;
var backgroundColor = Color.Red;
//  let message = 'abc';
//  let endsWithC = message.endsWith('c');
var message;
message = 'abc';
var endsWithC = message.endsWith('c');
var alternativeWay = message.endsWith('c');
var log = function (message) {
    console.log(message);
};
//with parameter
var doLog = function (message) { return console.log(message); };
// let drawPoint = (point: Point) => {
//     //...
//  } 
//  let getDistance = (pointA: Point, pointB: Point) => {
//      // ...
//  }
//  drawPoint({
//      x: 1,
//      y: 2
//  })
// With Class version 3
var PointNew = /** @class */ (function () {
    //  private x: number;
    //  private y: number;
    function PointNew(x, y) {
        this.x = x;
        this.y = y;
        // this.x = x;
        // this.y = y;
    }
    PointNew.prototype.draw = function () {
        console.log('X: ' + this.x + ', Y: ' + this.y);
    };
    PointNew.prototype.getDistance = function (another) {
        // ... 
    };
    return PointNew;
}());
var point = new PointNew(1, 2);
var pointn = new PointNew();
//x not accessable because x is private property and accessable only within PointNew Class
point.x = 3;
console.log(point.x);
// point.x = 1;
// point.y= 2;
point.draw();
