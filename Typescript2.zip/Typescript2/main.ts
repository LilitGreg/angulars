// function log(message){
//   console.log(message);
// }

// var message = 'Hello World';

// log(message);

function doSomething() {

    for(let i = 0 ; i < 5 ; i ++) {
        console.log(i);
    }

    console.log('Finally: ' + i);
}

doSomething();



// let count = 5;
// count ='a';

let a:number;
a = 1;
//warning type
// a= true;
// a ='a';

let b:boolean;
let c: string;
let d: any;
let e: number[] = [1,2,3];
let f : any[] =[1, true, 'a', false];


const ColorRed = 0;
const ColorGreen = 1;
const ColorBlue = 2;

enum Color{ Red = 0 , Green = 1, Blue = 2};
let  backgroundColor = Color.Red;


//  let message = 'abc';
//  let endsWithC = message.endsWith('c');

 
let message;
message = 'abc';
let endsWithC = (<string>message).endsWith('c');
let alternativeWay = (message as string).endsWith('c');



let log = function(message) {
    console.log(message);
}

//with parameter

let doLog = (message) => console.log(message);

//without prameter

//// let doLog = () => console.log();


// let drawPoint = (x, y, a, b, c, d, e) => {
//    //...
// }




 /// 1 version 

// let drawPoint = (point: { x: number, y: number}) => {
//     //...
//  }

// With interface version 2

interface Point {
    x: number,
    y: number
   // draw: () => void
}

// let drawPoint = (point: Point) => {
//     //...
//  } 


//  let getDistance = (pointA: Point, pointB: Point) => {
//      // ...
//  }

//  drawPoint({
//      x: 1,
//      y: 2
//  })


 // With Class version 3

 class PointNew {
    //  private x: number;
    //  private y: number;

     constructor (private  _x?: number, private _y?: number){
        // this.x = x;
        // this.y = y;
     }

      draw() {
         console.log('X: ' + this._x + ', Y: ' + this._y)
     }

     getDistance(another: Point) {
         // ... 
     }
    //  getX() {
    //      return this.x;
    //  }

    //  setX(value) {
    //     if( value < 0) 
           
        
    //       throw new Error("value cannot be less than 0.");
        
    //        this.x = value;
        
    //  }

     get x() {
        return this._x;
    }

    set x(value) {
       if( value < 0) 
          throw new Error("value cannot be less than 0.");
          this._x = value;
    }
 }
 

import { PointNewV } from './point';
let pointv = new PointNewV(1,2);
 


let point = new PointNew(1,2);
let pointn = new PointNew();

//x not accessable because x is private property and accessable only within PointNew Class

///point.x =3;
////console.log(point.x);

// point.getX();

// point.setX(10);

point.x;

point.x = 10;

// point.x = 1;
// point.y= 2;
point.draw();










