var myString;
var myNum;
var myBool;
var myVar;
// let strArr : string[];
// let numArr  : number[];
// let boolArr : boolean[];
var strArr;
var numArr;
var boolArr;
var strNumTuple;
myString = 'Hello'.slice(0, 3);
myNum = 1;
myBool = false;
myVar = true;
strArr = ['Hello', 'World'];
numArr = [1, 2, 3];
boolArr = [true, false, false];
strNumTuple = ['Hello', 3];
//true undefined and null values for void type
// let myVoid: void = undefined;
var myVoid = null;
//true for null type null and undefined values
var myNull = undefined;
//true for undefined type null and undefined values
var myUndefined = undefined;
console.log(myVoid);
